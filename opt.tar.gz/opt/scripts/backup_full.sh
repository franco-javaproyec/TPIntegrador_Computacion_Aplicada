#!/bin/bash

# backup_full.sh - TP Integrador (Punto 5)
# Uso: backup_full.sh ORIGEN DESTINO
# backup_full.sh -help

show_help(){
  echo "Uso: $0 ORIGEN DESTINO"
  echo "   ORIGEN: directorio a backupear (ej. /var/log o /www_dir)"
  echo "   DESTINO: directorio donde guardar el .tar.gz (ej. /www_dir)"
  echo "   Ejemplo: $0 /var/log /backup_dir"
}

#Opción de ayuda
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
  show_help
  exit 0
fi

ORIGEN=$1
DESTINO=$2

# Validaciones minimas de argumentos
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
  echo "Error: falta argumentos."
  show_help
  exit 1
fi

# Validar que ORIGEN exista y sea directorio
if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: el origen '$ORIGEN' no existe o no es un directorio."
  exit 2
fi

# Validar que DESTINO exista y sea directorio
if [[ ! -d "$DESTINO" ]]; then
  echo "Error: el destino '$DESTINO' no existe o no es un directorio."
  exit 3
fi

# Validar que el FS del DESTINO este disponible (df fallaria si no)
if ! df "$DESTINO" >/dev/null 2>&1; then
  echo "Error: el sistema de archivos de '$DESTINO' no esta disponible."
  exit 4
fi

# Fecha en formato ANSI YYYYMMDD (como pide en la consigna)
FECHA="$(date +%Y%m%d)"


# Derivar un nombre base segun el origen (/var/log -> log_bkp_YYYYMMDD.tar.gz)
BASE="$(basename "$ORIGEN")"

# Si es log(s), usamos 'log_bkp'; si no, usamos el nombre del directorio
case "$BASE" in
  log|logs) PREFIX="log_bkp" ;;
  www_dir) PREFIX="www_bkp" ;;
  *) PREFIX="{BASE}_bkp" ;;
esac

# Construir nombre de archivo final en el DESTINO
OUTFILE="${DESTINO}/${PREFIX}_${FECHA}.tar.gz"

# Para no guardar rutas absolutas, ubicamos el tar en el padre del origen
ORIGEN_PADRE="$(dirname "$ORIGEN")"
ORIGEN_NOMBRE="$(basename "$ORIGEN")" 

echo "Creando backup de '$ORIGEN' en '$OUTFILE'..."
tar -C "$ORIGEN_PADRE" -czf "$OUTFILE" "$ORIGEN_NOMBRE"
RC=$?

if [[ $RC -ne 0 ]]; then
   echo "Error: fallo la generacion de backup (tar rc=$RC)."
   exit 5
fi


echo "Backup OK: $OUTFILE"
exit 0




